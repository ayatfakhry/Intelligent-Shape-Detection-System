
# Intelligent Shape Detection & Geometric Understanding System

A multi-level computer vision and AI system for geometric shape detection, analysis, and tracking simulation.

## Features
- Classical Computer Vision using OpenCV
- Shape detection and classification
- Geometry extraction: area, perimeter, centroid, bounding box
- Color analysis
- Confidence scoring
- Random Forest AI classifier
- Hybrid confidence-aware detection
- YOLOv8 deep learning object detection
- Classical CV vs YOLO comparison
- Video-frame detection simulation
- Detection stability score
- Virtual tracking simulation

## Technologies
Python, OpenCV, NumPy, Pandas, Matplotlib, Scikit-learn, Ultralytics YOLOv8, Google Colab.

## Project Value
This project demonstrates a complete computer vision workflow from classical image processing to machine learning and YOLO-based deep learning detection.

## Final Statement
Developed a multi-level intelligent vision system combining classical computer vision, machine learning, YOLOv8 deep learning, robustness analysis, video simulation, and virtual tracking.
